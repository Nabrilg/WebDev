﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDev.Application.Config
{
    public class ApiConfiguration
    {
        public string ApiUsersUrl { get; set; }
        public string ApiLoginUrl { get; set; }
    }
}