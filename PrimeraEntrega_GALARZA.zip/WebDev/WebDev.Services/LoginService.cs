﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using WebDev.Services.Entities;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using WebDev.Services.Helpers;

namespace WebDev.Services
{
    public class LoginService{
        private readonly RestClient _restClient;
        private string BaseUrl { get; }
        public LoginService(string baseUrl){
            BaseUrl = baseUrl;
            _restClient = new RestClient();
        }

        //Metodos del Usuario
        public async Task<TokenDto> ValideUser(LoginDto login){
            TokenDto tokenDto = null;

            _restClient.BaseUrl = new Uri($"{BaseUrl}login");
            _restClient.Timeout = -1;

            var request = new RestRequest(Method.POST);
            var content = JsonConvert.SerializeObject(login);

            request.AddParameter("application/json", content, ParameterType.RequestBody);
            request.AddHeader("Content-Type", "application/json");

            IRestResponse response = await _restClient.ExecuteAsync(request);

            if (response.StatusCode == HttpStatusCode.OK){
                var responseContent = response.Content;
                tokenDto = JsonConvert.DeserializeObject<TokenDto>(responseContent);
            }
            else{
                Console.WriteLine("Login Failure! ");
                return null;
            }
            GlobalVariables.tokenDto = tokenDto;
            return tokenDto;
        }
    }
}
