﻿using System;
using System.Collections.Generic;
using System.Text;
using WebDev.Services.Entities;

namespace WebDev.Services.Helpers
{
    public static class GlobalVariables
    {
        public static TokenDto tokenDto = null;
    }
}
