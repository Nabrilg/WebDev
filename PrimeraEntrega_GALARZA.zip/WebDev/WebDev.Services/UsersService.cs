﻿using System;
using RestSharp;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using WebDev.Services.Entities;
using Newtonsoft.Json;
using System.Net;
using WebDev.Services.Helpers;

namespace WebDev.Services
{
    public class UsersService{
        public UsersService(string baseUrl){
            BaseUrl = baseUrl;
            _restClient = new RestClient();
        }
        private readonly RestClient _restClient;
        public string BaseUrl { get; } 

        //Implementacion del usuario y funciones relacionadas

        public async Task<List<UserDto>> GetUsers(){
            List<UserDto> listUser = null;

            _restClient.BaseUrl = new Uri($"{BaseUrl}users");
            _restClient.Timeout = -1;

            var request = new RestRequest(Method.GET);

            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("authorization", GlobalVariables.tokenDto.Token);

            IRestResponse response = await _restClient.ExecuteAsync(request);

            if(response.StatusCode == HttpStatusCode.OK)
            {
            var responseContent = response.Content;
            listUser = JsonConvert.DeserializeObject<List<UserDto>>(responseContent);
            }
            else
            {
                Console.WriteLine("User not found! ");
                return null;
            }
            return listUser;
        }

        public async Task<UserDto> GetUserById(int id){
            UserDto user = null;

            _restClient.BaseUrl = new Uri($"{BaseUrl}users/" + id);
            _restClient.Timeout = -1;

            var request = new RestRequest(Method.GET);

            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("authorization", GlobalVariables.tokenDto.Token);

            IRestResponse response = await _restClient.ExecuteAsync(request);

            if (response.StatusCode == HttpStatusCode.OK){
                    var responseContent = response.Content;
                    user = JsonConvert.DeserializeObject<UserDto>(responseContent);
            }
            else{
                    Console.WriteLine("ID not found! ");
                    return null;
            }
            return user;
        }

        //Añadir
        public async Task<UserDto> AddUser(UserDto user){
            UserDto userDtoResponse = null;

            _restClient.BaseUrl = new Uri($"{BaseUrl}users");
            _restClient.Timeout = -1;

            var request = new RestRequest(Method.POST);
            var content = JsonConvert.SerializeObject(user);

            request.AddParameter("application/json", content, ParameterType.RequestBody);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("authorization", GlobalVariables.tokenDto.Token);

            IRestResponse response = await _restClient.ExecuteAsync(request);

            if (response.StatusCode == HttpStatusCode.OK){
                var responseContent = response.Content;
                userDtoResponse = JsonConvert.DeserializeObject<UserDto>(responseContent);
            }
            else{
                Console.WriteLine("User not added!");
                return null;
            }
            return userDtoResponse;
        }

        //Actualizar
        public async Task<UserDto> UpdateUser(UserDto user){

            UserDto userDtoResponse = null;

            _restClient.BaseUrl = new Uri($"{BaseUrl}users/" + user.id);
            _restClient.Timeout = -1;

            var request = new RestRequest(Method.PUT);
            var content = JsonConvert.SerializeObject(user);

            request.AddParameter("application/json", content, ParameterType.RequestBody);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("authorization", GlobalVariables.tokenDto.Token);

            IRestResponse response = await _restClient.ExecuteAsync(request);

            if (response.StatusCode == HttpStatusCode.OK){
                var responseContent = response.Content;
                userDtoResponse = JsonConvert.DeserializeObject<UserDto>(responseContent);
            }
            else{
                Console.WriteLine("User not Update! ");
                return null;
            }
            return userDtoResponse;
        }
        
        //Eliminar
        public async Task<UserDto> DeleteUser(int id){
            UserDto userDtoResponse = null;

            _restClient.BaseUrl = new Uri($"{BaseUrl}users/" + id);
            _restClient.Timeout = -1;

            var request = new RestRequest(Method.DELETE);

            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("authorization", GlobalVariables.tokenDto.Token);

            IRestResponse response = await _restClient.ExecuteAsync(request);

            if (response.StatusCode == HttpStatusCode.OK){
                var responseContent = response.Content;
                userDtoResponse = JsonConvert.DeserializeObject<UserDto>(responseContent);
            }

            else{
                Console.WriteLine("User not Deleted! ");
                return null;
            } 
            return userDtoResponse;
        }

    }
}
